import { Observable } from '../Observable';
export declare const toPromise: typeof Observable.prototype.toPromise;
