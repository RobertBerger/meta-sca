"use strict";
var Observable_1 = require('../Observable');
// HACK: this is here for backward compatability
// TODO(benlesh): remove this in v6.
exports.toPromise = Observable_1.Observable.prototype.toPromise;
//# sourceMappingURL=toPromise.js.map