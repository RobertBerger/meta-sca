# Change Log

All notable changes to this project will be documented in the
[`standard` CHANGELOG](https://github.com/feross/standard/blob/master/CHANGELOG.md).

This project's
[commit log](https://github.com/feross/eslint-config-standard/commits/master) is
also quite readable.

This project adheres to [Semantic Versioning](http://semver.org/).
